﻿$password = Read-Host -AsSecureString password
$n = New-Object -ComObject internetexplorer.application
$n.navigate('google.com')
$n.visible=$true
while($n.busy){
Start-Sleep -Seconds 2}
$n.document.getelementbyid('lst-ib').value=('coursera')
$n.document.forms[0].submit()
while($n.busy){
Start-Sleep -Seconds 2}
$a = $n.document.getelementsbytagname('a') | ? { $_.textcontent -eq 'coursera | online courses & credentials by top educators. join for free'}
$a.click()
while($n.busy){
Start-Sleep -Seconds 2}
$b = $n.document.getelementsbytagname('a') | ? { $_.textcontent -eq 'log in'}
$b.click()
$n.document.getelementbyid('emailinput-input').value= 'babupvijay@gmail.com'
$n.document.getelementbyid('passwordinput-input').value= $password
$g = ($n.document.getelementsbytagname('span') | ? { $_.classname -eq 'box_120drhm-o_0-centerjustify_1nezfbd-o_0-centeralign_19zvu2s-o_0-display'}).click()