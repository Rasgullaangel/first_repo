﻿$a = get-service | select -First 10
$a =[pscustomobject]$a
$b = $a | ConvertTo-Html
$b | out-file C:\users\pulakanam.v\Desktop\email.html
$c = New-Object -ComObject outlook.application
$d = $c.CreateItem(0)
$d.To ="senthilnathanp@hcl.com"
$d.Subject = "sending a html file" 
$d.body="hiii ! this is vijay"     
$file= "C:/Users/pulakanam.v/Desktop/email.html"
$at = New-Object System.Net.Mail.Attachment $file
$d.attachments.add($file)
$d.Send()
