﻿#$a='gayathri9042@gmail.com'
#$b='Abcd@123'
$n = New-Object -ComObject internetexplorer.application 
$n.Navigate('https://google.co.in')
$n.visible=$true
while($n.busy){
start-sleep -Seconds 2 }
$n.Document.getElementById('lst-ib').value='indeed.com'
while($n.busy){
start-sleep -Seconds 2 }

$n.Document.forms[0].submit()
while($n.busy){
start-sleep -Seconds 2 }

$n.Document.getElementById('gsr').click()
while($n.busy){
start-sleep -Seconds 1 }












