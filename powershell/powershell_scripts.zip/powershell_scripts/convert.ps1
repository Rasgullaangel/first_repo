﻿$a = Get-Service | select -first 10 
$a | out-file -FilePath C:\Users\pulakanam.v\Desktop\ccsv.csv
$b = Get-Content C:\Users\pulakanam.v\Desktop\f1.csv
$b | out-file -FilePath C:\Users\pulakanam.v\Desktop\xcel.xls

$c = get-content C:\Users\pulakanam.v\Desktop\xcel.xls | Format-Table -AutoSize | ConvertTo-Csv
convertfrom-csv -InputObject $a | out-file -FilePath C:\Users\pulakanam.v\Desktop\ccsv.csv