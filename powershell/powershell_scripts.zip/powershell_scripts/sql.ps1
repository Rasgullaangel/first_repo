﻿#sql
import-module sqlps -DisableNameChecking #for this execution policy must be in unrestricted or remote signed
[string] $Server= " HEARTTHROB"
[string] $Database = "USERDB"
[string] $SqlQuery= $("SELECT count ( *)   FROM [Sales]")
$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $Connection
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server = $Server; Database = $Database; Integrated Security = True;"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $SqlQuery
$SqlCmd.Connection = $SqlConnection
$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
$SqlAdapter.SelectCommand = $SqlCmd
$DataSet = New-Object System.Data.DataSet
$SqlAdapter.Fill($DataSet)
$DataSet.Tables[0] | out-file "C:\Users\pulakanam.v\desktop\sql1.csv"
 

