﻿#$a = get-service | select -First 5
#$a | ConvertTo-Html | out-file C:\Users\pulakanam.v\Desktop\vij.html
#Get-Process | export-csv C:\Users\pulakanam.v\desktop\vij.csv -NoTypeInformation -Force | ft -AutoSize 
#Start-Transcript
#Stop-Transcript
$s=@('servpod1','servpod2','servpod3','servdev1','servdev2','servdev3') 
$s1=@()
$s2=@()
foreach($item in $s){
if($item -like "*pod*"){
$s1 +=  $item
}
elseif($item -like "*dev*"){
$s2 += $item
}
}
if($s1.count -gt 0){
$obj=$s1 | Select-Object @{name='productserver';expression={$_}}
$obj | Export-Csv -Path C:\Users\pulakanam.v\Desktop\prod.csv -NoTypeInformation}
if($s2.count -gt 0){
$obj=$s2 | Select-Object @{name='productserver';expression={$_}}
$obj | Export-Csv -Path C:\Users\pulakanam.v\Desktop\prod.csv -NoTypeInformation}