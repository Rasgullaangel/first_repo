﻿#creating a  button
add-type -AssemblyName system.windows.forms
$form = New-Object system.windows.forms.form
$form.text = "button"
$form.Width=300
$form.Height=300

$button1 = New-Object System.Windows.Forms.Button
$button1.Text = "OK"
$button1.Location = New-Object System.Drawing.Point(75,120)
$button1.Size = New-Object System.Drawing.size(75,23)
$button1.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $button1
$form.controls.add($button1)

$form.ShowDialog()