﻿#creating a textbox
add-type -AssemblyName system.windows.forms
$form = New-Object system.windows.forms.form
$form.text = "textbox"
$form.Width=300
$form.Height=300

$textbox = New-Object System.Windows.Forms.TextBox
$textbox.Location = New-Object System.Drawing.Point(10,40)
$textbox.Size = New-Object System.Drawing.size(260,20)
$form.add_shown({$textbox.Select()})

$form.controls.add($textbox)
$form.ShowDialog()