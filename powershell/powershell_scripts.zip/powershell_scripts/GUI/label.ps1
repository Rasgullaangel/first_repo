﻿#creating a label
add-type -AssemblyName system.windows.forms
$form = New-Object system.windows.forms.form
$form.text = "label"
$form.Width=300
$form.Height=300

$label =New-Object system.windows.forms.label
$label.Text = "sample label"
$label.Location = New-Object drawing.point (40,40)
$label.size = New-Object drawing.size (70,30)
$label.left = 70
$label.region = New-Object drawing.region(40,30)
$label.BackColor="red"
$form.controls.add($label)


$form.ShowDialog()