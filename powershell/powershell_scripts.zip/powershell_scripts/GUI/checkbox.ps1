﻿#create a checkbox
add-type -AssemblyName system.windows.forms
$form = New-Object system.windows.forms.form
$form.text = "checkbox"
$form.Width=300
$form.Height=300

$checkbox1 = New-Object System.Windows.Forms.CheckBox
$checkbox2 = New-Object system.Windows.Forms.CheckBox
$checkbox3 = New-Object system.Windows.Forms.CheckBox
$checkbox1.Location = New-Object System.Drawing.Point(75,120)
$checkbox1.Size = New-Object System.Drawing.Size(75,23)
$checkbox2.Location = New-Object System.Drawing.Point(150,120)
$checkbox2.Size = New-Object System.Drawing.Size(150,23)


$checkbox1.text = "vijay"
$checkbox2.text = "vijay1"
<#$checkbox1.AutoCheck =$true
$checkbox2.AutoCheck =$true#>
$form.controls.add($checkbox1)
$form.controls.add($checkbox2)
if($checkbox1.checked = $true){
$checkbox2.Checked = $false}
else{$checkbox2.Checked = $true}

$form.ShowDialog()
