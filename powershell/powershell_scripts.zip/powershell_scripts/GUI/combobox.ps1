﻿$form = New-Object System.Windows.Forms.Form
$form.width = 300
$form.height = 150
$form.Text= "combo box"

$DropDown = new-object System.Windows.Forms.ComboBox
$DropDown.Location = new-object System.Drawing.point(100,10)
$DropDown.Size = new-object System.Drawing.Size(130,30)
$Form.Controls.Add($DropDown)


$a = @("vijay","ranjith","rajesh","praveen","pooja","lathika","gayathri")
ForEach ($Item in $a) {
	$DropDown.Items.Add($Item)
}
$DropDownLabel = new-object System.Windows.Forms.Label
$DropDownLabel.Location = new-object System.Drawing.point(10,10)
$DropDownLabel.size = new-object System.Drawing.Size(80,20)
$DropDownLabel.text = " i am label"
$Form.Controls.Add($DropDownLabel)


$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(100,50)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "OK"
$Button.Add_Click({DropDown})
$form.Controls.Add($Button)

function DropDown {

	$Choice = $DropDown.SelectedItem.ToString()
	$Form.Close()
        if ($choice -eq "vijay") 
        {
            write-host $Choice        
        }
        elseif ($choice -eq "ranjith") 
        {
            write-host "$choice"
           
        }

        elseif ($choice -eq "nslookup") 
        {
            write-host "NSLOOKUP $args"
            .\nslookup $args
            write-host
        }    	
}



$form.ShowDialog()