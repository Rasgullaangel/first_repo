﻿$a=add-type -AssemblyName presentationcore,presentationframework
$ButtonType = [System.Windows.MessageBoxButton]::Yes
$ButtonType1 = [System.Windows.MessageBoxButton]::no
$MessageboxTitle = “Test pop-up message title”
$Messageboxbody = “this is message"
$MessageIcon = [System.Windows.MessageBoxImage]::Warning
[System.Windows.MessageBox]::Show($buttontype,$ButtonType1,$MessageIcon)