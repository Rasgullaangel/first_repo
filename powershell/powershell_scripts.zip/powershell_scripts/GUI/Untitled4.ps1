﻿#calculator
add-type -assemblyname system.windows.forms
$form = New-Object System.Windows.Forms.Form
$form.text ="my calculator"
$form.width = 350
$form.height = 350
$font = New-Object System.Drawing.font("times new roman",14)
$form.Font=$font

$label = New-Object System.Windows.Forms.Label
$label.Text = 'standard'
$form.Controls.add($label)

$textBoxDisplay = New-Object System.Windows.Forms.TextBox
$form.Controls.add($textboxdisplay)
$textBoxDisplay.Location = New-Object System.Drawing.Size(0,30)
$textBoxDisplay.size= New-Object System.Drawing.Size(400,800)


$button = New-Object System.Windows.Forms.Button
$form.Controls.add($button)
$button.Text = "C"
$button.Visible = $true
$button.Location = New-Object System.Drawing.Size(0,70)
$button.add_click{$textBoxDisplay.text =  ' '}

$button1 = New-Object System.Windows.Forms.Button
$form.Controls.add($button1)
$button1.Text = "CE"
$button1.Location = New-Object System.Drawing.Size(80,70)
$button1.add_click{$textBoxDisplay.text =  ' '}

$button2 = New-Object System.Windows.Forms.Button
$form.Controls.add($button2)
$button2.Text = "BS"
$button2.Location = New-Object System.Drawing.Size(160,70)
$button2.add_click{$textBoxDisplay.text = $textBoxDisplay.Text | %{$_.substring(0,$_.length-1)}}

$button3 = New-Object System.Windows.Forms.Button
$form.Controls.add($button3)
$button3.Text = "/"
$button3.Location = New-Object System.Drawing.Size(240,70)
$button3.add_click({
if($textBoxDisplay.Text[-1] -eq '*'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '+'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '-'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '/'){
$textBoxDisplay.text+= ''}
else{$textBoxDisplay.Text += '/'}
})

$button4 = New-Object System.Windows.Forms.Button
$form.Controls.add($button4)
$button4.Text = "7"
$button4.Location = New-Object System.Drawing.Size(0,95)
$button4.add_click{$textBoxDisplay.text +=  '7'}

$button5 = New-Object System.Windows.Forms.Button
$form.Controls.add($button5)
$button5.Text = "8"
$button5.Location = New-Object System.Drawing.Size(80,95)
$button5.add_click{$textBoxDisplay.text +=  '8'}

$button6 = New-Object System.Windows.Forms.Button
$form.Controls.add($button6)
$button6.Text = "9"
$button6.Location = New-Object System.Drawing.Size(160,95)
$button6.add_click{$textBoxDisplay.text +=  '9'}

$button7 = New-Object System.Windows.Forms.Button
$form.Controls.add($button7)
$button7.Text = "4"
$button7.Location = New-Object System.Drawing.Size(0,120)
$button7.add_click{$textBoxDisplay.text +=  '4'}

$button8 = New-Object System.Windows.Forms.Button
$form.Controls.add($button8)
$button8.Text = "5"
$button8.Location = New-Object System.Drawing.Size(80,120)
$button8.add_click{$textBoxDisplay.text +=  '5'}

$button9 = New-Object System.Windows.Forms.Button
$form.Controls.add($button9)
$button9.Text = "6"
$button9.Location = New-Object System.Drawing.Size(160,120)
$button9.add_click{$textBoxDisplay.text +=  '6'}

$button10 = New-Object System.Windows.Forms.Button
$form.Controls.add($button10)
$button10.Text = "1"
$button10.Location = New-Object System.Drawing.Size(0,145)
$button10.add_click{$textBoxDisplay.text +=  '1'}

$button11 = New-Object System.Windows.Forms.Button
$form.Controls.add($button11)
$button11.Text = "2"
$button11.Location = New-Object System.Drawing.Size(80,145)
$button11.add_click{$textBoxDisplay.text +=  '2'}

$button12 = New-Object System.Windows.Forms.Button
$form.Controls.add($button12)
$button12.Text = "3"
$button12.Location = New-Object System.Drawing.Size(160,145)
$button12.add_click{$textBoxDisplay.text +=  '3'}

$button13 = New-Object System.Windows.Forms.Button
$form.Controls.add($button13)
$button13.Text = "0"
$button13.Location = New-Object System.Drawing.Size(75,170)
$button13.add_click{$textBoxDisplay.text +=  '0'}

$button14 = New-Object System.Windows.Forms.Button
$form.Controls.add($button14)
$button14.Text = "+"
$button14.Location = New-Object System.Drawing.Size(240,95)
$button14.add_click({
if($textBoxDisplay.Text[-1] -eq '*'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '+'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '-'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '/'){
$textBoxDisplay.text+= ''}
else{$textBoxDisplay.Text += '+'}
})

$button15 = New-Object System.Windows.Forms.Button
$form.Controls.add($button15)
$button15.Text = "*"
$button15.Location = New-Object System.Drawing.Size(240,145)
$button15.add_click({
if($textBoxDisplay.Text[-1] -eq '*'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '+'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '-'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '/'){
$textBoxDisplay.text+= ''}
else{$textBoxDisplay.Text += '*'}
})


$button16 = New-Object System.Windows.Forms.Button
$form.Controls.add($button16)
$button16.Text = "-"
$button16.Location = New-Object System.Drawing.Size(240,120)
$button16.add_click({
if($textBoxDisplay.Text[-1] -eq '*'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '+'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '-'){
$textBoxDisplay.text+= ''}
elseif($textBoxDisplay.Text[-1] -eq '/'){
$textBoxDisplay.text+= ''}
else{$textBoxDisplay.Text += '-'}
})

$button17 = New-Object System.Windows.Forms.Button
$form.Controls.add($button17)
$button17.Text = "="
$button17.Location = New-Object System.Drawing.Size(240,170)
$button17.add_click({$textBoxDisplay.text = Invoke-Expression $textBoxDisplay.text})

$button18 = New-Object System.Windows.Forms.Button
$form.Controls.add($button18)
$button18.Text = "("
$button18.Location = New-Object System.Drawing.Size(0,170)
$button18.add_click{$textBoxDisplay.text +=  '('}

$button19 = New-Object System.Windows.Forms.Button
$form.Controls.add($button19)
$button19.Text = ")"
$button19.Location = New-Object System.Drawing.Size(160,170)
$button19.add_click{$textBoxDisplay.text +=  ')'}

$form.showdialog() 