﻿#creating a form
add-type -AssemblyName system.windows.forms
$form = New-Object System.Windows.Forms.Form
$form.text="vijay"

#font
$font = New-Object System.Drawing.font("times new roman",14)
$form.Font=$font

#dimensions
$form.Width =200
$form.height=200

#enabling autoscroll
$form.autoscroll=$true

#enabling autosize
$form.AutoSize=$true
$form.AutoSizeMode = "growandshrink"

#minimize,maximize,windowstate
$form.MinimizeBox=$true
$form.MaximizeBox=$true
$form.WindowState="normal"

#show,auto,hide
$form.SizeGripStyle="show"

#show in taskbar
$form.ShowInTaskbar=$true

#opacity 1.0 = visible , 0.0 = opaque
$form.Opacity=1.0

#centerscreen , manual , windowsdefaultlocation
$form.StartPosition = "manual"

#backgroundcolor
$form.BackColor="lime"

#background image
#$image = [System.Drawing.Image]::FromFile("path")
#$form.backgroundimage=$image

#icon
#$icon = New-Object system.drawing.icon("c:\users\pulakanam.v\desktop\menu.jpg")
#$form.icon=$icon

$form.TopMost = $true
$form.ShowDialog()