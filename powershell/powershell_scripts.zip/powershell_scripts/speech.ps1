﻿add-type -AssemblyName system.speech
$speak = New-Object system.speech.Synthesis.SpeechSynthesizer
$speak1 = New-Object System.Speech.Recognition.SpeechRecognizer
#$speak.Pause()
#$speak.Resume()
$speak.Volume = 12
$speak.Speak("vijay")
$speak.SetOutputToWaveFile("C:\users\pulakanam.v\Desktop\test1.wav")
$speak.dispose()
$a = (New-Object media.soundplayer "c:\users\pulakanam.v\desktop\k.wav").PlaySync()
#$a.ToString($a)
