﻿function email{
    param()
    $a = get-service | select -first 5
    $a =[pscustomobject]$a
    $b = $a | ConvertTo-Html
    $b | out-file C:\users\pulakanam.v\Desktop\email.html
    $c = New-Object -ComObject outlook.application
    $d = $c.CreateItem(0)
    $d.To ="senthilnathanp@hcl.com"
    $d.Subject = "sending a html file"     
    $file= "C:/Users/pulakanam.v/Desktop/email.html"
    $at = New-Object System.Net.Mail.Attachment $file
    $d.attachments.add($file)
    $d.Send()
}


function con-csv-xcel{
        param()
        $a = New-Object -ComObject excel.application
        $csv = Read-Host " enter the path"
        $out = Read-Host " enter the path"
        $workbook = $a.Workbooks.Open($xcel)
        $workbook.SaveAs($out,1)
        $workbook.saved=$true
        $a.quit()
        
        }

function con-xcel-csv{
        param()
        $a = New-Object -ComObject excel.application
        $xcel = Read-Host " enter the path"
        $out = Read-Host " enter the path"
        $workbook = $a.Workbooks.Open($xcel)
        $workbook.SaveAs($out,1)
        $workbook.saved=$true
        $a.quit()
}
 do{
 write-host " 1.email 2.con-csv-xcel 3.con-xcel-csv 4.exit"
 $opt = Read-Host "enter option"
 switch($opt){
 1{email(0)
    write-host "mail send successfully"}
 2{con-csv-xcel(0)
    write-host "converted sucessfully"}
 3{con-xcel-csv(0)
    write-host "converted successfully"}
    }
    }while($opt -ne 4)
