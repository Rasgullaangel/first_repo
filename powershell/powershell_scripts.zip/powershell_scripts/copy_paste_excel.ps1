﻿$src = Write-Host "enter the source path"
$des = Write-Host "enter the destination path"
$excel = New-Object -ComObject excel.application
$excel.visible = $true
$workbook = $excel.workbooks.open($src)
$worksheet = $workbook.worksheets.item(1)          #else give the sheet name in the item argument
$worksheet.activate()
$range = $worksheet.range("A1:B1").entirecolumn    #instead give entirerow
$range.copy() | Out-Null
$workbook = $excel.workbooks.open($des) 
$worksheet = $workbook.worksheets.item(1)
$range = $worksheet.range("A1")                    #a1 indicates the destination cell
$worksheet.paste($range)
$workbook.save()
$excel.quit()
 