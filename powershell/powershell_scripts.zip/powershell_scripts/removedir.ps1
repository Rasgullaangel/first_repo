﻿New-Item -ItemType directory -Path C:\Users\pulakanam.v\Desktop\myinventory\folder
Remove-Item  C:\Users\pulakanam.v\Desktop\myinventory\folder