﻿$a=Get-WmiObject -class win32_logicaldisk | select @{n='capacity';e={((($_.size)-($_.freespace))/($_.size))*100}},@{n='FreeSpace';e={($_.FreeSpace/$_.size)*100}}
$b=Get-WmiObject -class Win32_PerfFormattedData_Tcpip_NetworkInterface |
    Select @{n='Nic_Card';e={$_.name}},@{n='current';e={($_.currentbandwidth/100000000)*100}} |?{$_.Nic_Card -like 'intel*'}
$c= Get-WmiObject -class win32_processor | select loadpercentage,@{n='CPU';e={$_.name}}
$output=@()
$d=@()
$d=get-content -path C:\Users\pulakanam.v\Desktop\vijay.txt
for($i=0;$i -lt 5;$i++) {
 
$a1=$O = New-Object PSObject;
$a2=$O | Add-Member NoteProperty "Servers" $d[$i];
$a3=$O | Add-Member NoteProperty "Cpu" $c.Cpu;
$a4=$O | Add-Member NoteProperty "LoadPercent" $c.loadpercentage;
$a5=$O | Add-Member NoteProperty "NicCard" $b.Nic_Card;
$a6=$O | Add-Member NoteProperty "CurrentBandwidth" $b.CurrentBandWidth;
$a7=$O | Add-Member NoteProperty "Capacity" $a.capacity;
$a8=$O | Add-Member NoteProperty "FreeSPace" $a.FreeSpace;
$Output += $O;
 
} 
$path="C:\Users\pulakanam.v\desktop\task.txt"
$text = $output | ConvertTo-Html
$text1 = $text -replace '<table>','<Table border=1 cellpadding=0 cellspacing=0>'
$ou = New-Object -ComObject outlook.application
$mail = $ou.CreateItem(0)
$mail.to = "senthilnathanp@hcl.com"
$mail.subject = "task output"
$mail.HTMLBody= "$text1"
$mail.attachments.add($path)
$mail.send() 