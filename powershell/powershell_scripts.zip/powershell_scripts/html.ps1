﻿$ServerList = Get-Content -Path C:\users\lukka.r\Desktop\server.txt  
$Result = @()  
ForEach($computername in $ServerList)  
{ 
    $AVGProc = Get-WmiObject -computername $computername win32_processor |  
    Measure-Object -property LoadPercentage -Average | Select Average 
    $OS = gwmi -Class win32_operatingsystem -computername $computername | 
    Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }} 
    $vol = Get-WmiObject -Class win32_Volume -ComputerName $computername -Filter "DriveLetter = 'C:'" | 
    Select-object @{Name = "C PercentFree"; Expression = {“{0:N2}” -f  (($_.FreeSpace / $_.Capacity)*100) } } 
    $b=Get-WmiObject -class Win32_PerfFormattedData_Tcpip_NetworkInterface |
    Select @{n='Nic_Card';e={$_.name}},CurrentBandWidth |?{$_.Nic_Card -like 'intel*'} 
      
    $result += [PSCustomObject] @{  
            ServerName = "$computername" 
            CPUutilization = "$($AVGProc.Average)%" 
            Memutilization = "$($OS.MemoryUsage)%" 
            CDrive = "$($vol.'C PercentFree')%"
            Bandwidth = "$($b.currentbandwidth)"
            Nic_card = "$($b.nic_card)"
        } 
          $Outputreport = "<HTML><TITLE> Server Health Report </TITLE> 
                       <BODY>
                       <Table border=1 cellpadding=0 cellspacing=0> 
                       <TR> 
                       <TD><B>Server Name</B></TD> 
                       <TD><B>Avrg.CPU Utilization</B></TD> 
                       <TD><B>Memory Utilization</B></TD> 
                       <TD><B>C Drive Utilizatoin</B></TD>
                       <TD><B>NetworkBandwidth</B></TD>
                       <TD><B>Nic_card</B></TD></TR>" 
          $Outputreport += "<TR>"  
                         
    Foreach($Entry in $Result)  
     
        {  
          $Outputreport += "<TD>$($Entry.Servername)</TD><TD align=center>$($Entry.CPUutilization)</TD><TD align=center>$($Entry.Memutilization)</TD><TD align=center>$($Entry.Cdrive)</TD><TD>$($Entry.Bandwidth)</TD><TD>$($Entry.nic_card)</TD></TR>"  
       }
     $Outputreport += "</Table></BODY></HTML>"  
}
$outputreport | Out-File -FilePath C:\users\lukka.r\Desktop\list.html
#$text = Get-Content -Path C:\users\lukka.r\Desktop\list.txt|Out-String
$ou = New-Object -ComObject outlook.application
$mail = $ou.CreateItem(0)
$mail.to = "tripathi.r@hcl.com"
$mail.subject = "Output of given task"
$mail.HTMLbody = $true
$mail.HTMLBody = $Outputreport
$mail.send() 

