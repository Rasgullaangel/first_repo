﻿$a=read-host "enter the input"
[int]$b=Read-Host "enter the number"
[int]$c=read-host "enter the number"
switch($a)
{
0{
$d=$b+$c
write-host "the number is :" $d
}
1{
$d=$b-$c
write-host "the number is :" $d
}
2{
$d=$b*$c
write-host "the number is :" $d
}
}