﻿#powershell gui
Add-Type -AssemblyName system.windows.forms
$form = New-Object system.windows.forms.form
$form.text = "calculator"
$form.AutoSize=$true
$font = New-Object System.Drawing.font("times new roman",14)
$form.Font=$font

#$icon = New-Object system.drawing.icon("c:\users\pulakanam.v\desktop\menu.jpg")
#$form.icon=$icon

$form.AutoScroll = $true

#$mouse = [system.windows.forms.cursor]::Current


$label =New-Object system.windows.forms.label
$label.Text = "standard"
$label.Location = New-Object Drawing.size (40,20)
$form.controls.add($label)


$textfield = New-Object Windows.Forms.TextBox
$textfield.Location = New-Object Drawing.size (50,60)
$textfield.Text = 0 
$textfield.width=800
$textfield.Height=400
$form.controls.add($textfield)

$button1 = New-Object System.Windows.Forms.Button
$button1.Text = "ce"
$button1.Location = New-Object Drawing.size (0,200)
$button.add_click({$textfield.text = "empty"})
$form.controls.add($button1)

$button2 = New-Object System.Windows.Forms.Button
$button2.Text = "c"
$button2.Location = New-Object Drawing.size (70,400)
$button.add_click({$textfield.text = '7'})
$form.controls.add($button2)

$button3 = New-Object System.Windows.Forms.Button
$button3.Text = "erase"
$button3.Location = New-Object Drawing.size (140,400)
$button.add_click({$textfield.text = '4'})
$form.controls.add($button3)

$button4 = New-Object System.Windows.Forms.Button
$button4.Text = "/"
$button4.Location = New-Object Drawing.size (210,400)
$button.add_click({$textfield.text = '1'})
$form.controls.add($button4)

$button5 = New-Object System.Windows.Forms.Button
$button5.Text = "7"
$button5.Location = New-Object Drawing.size (0,225)
$form.controls.add($button5)

$button6 = New-Object System.Windows.Forms.Button
$button6.Text = "4"
$button6.Location = New-Object Drawing.size (0,250)
$form.controls.add($button6)

$button7 = New-Object System.Windows.Forms.Button
$button7.Text = "1"
$button7.Location = New-Object Drawing.size (0,275)
$form.controls.add($button7)

$button8 = New-Object System.Windows.Forms.Button
$button8.Text = "+/-"
$button8.Location = New-Object Drawing.size (0,300)
$form.controls.add($button8)

$form.showdialog()
