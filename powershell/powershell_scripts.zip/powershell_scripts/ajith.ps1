﻿$a= Get-WmiObject -Class win32_logicaldisk 
$b= ($a.size - $a.FreeSpace)/1gb
$c=Get-WmiObject -Class win32_physicalmemory
$d=Get-WmiObject -Class Win32_OperatingSystem 
$e=($c.capacity-$d.FreePhysicalMemory )/1gb
$f=Get-WmiObject -class Win32_PerfFormattedData_Tcpip_NetworkInterface |
    Select @{name='NIC_Card';exp={$_.name}},CurrentBandWidth |?{$_.NIC_Card -like '*wireless*'}
$g=Get-WmiObject -Class Win32_processor | select loadpercentage,@{name='CPU';e={$_.name}}
$o=@()
$z=@()
$z=get-content -path C:\Users\ajithkannan.c\Desktop\ajith.txt

for($i=0;$i -lt 5;$i++){

$Out = New-Object PSObject;
$Out | Add-Member NoteProperty "Servers" $z[$i];
$Out | Add-Member NoteProperty "Memory" $e;
$Out | Add-Member NoteProperty "CPU" $g.CPU;
$Out | Add-Member NoteProperty "LoadPercentage" $g.loadpercentage;
$Out | Add-Member NoteProperty "CurrentBandwidth" $f.CurrentBandWidth;
$Out | Add-Member NoteProperty "NicCard" $f.NIC_Card;
$Out | Add-Member NoteProperty "DISK" $b;
$O+= $Out;
}
$ts="<html><body><Table border=1 cellpadding=0 cellspacing=0>"
$text = $o | ConvertTo-Html
$ts+=$text
$ts+="</html></body></table>"
$ts | Out-File -FilePath C:\Users\ajithkannan.c\Desktop\task.html
$te = Get-Content -Path C:\Users\ajithkannan.c\Desktop\task.html | Out-String
$ou = New-Object -ComObject outlook.application
$mail = $ou.CreateItem(0)
$mail.to = "ajithkannan.c@hcl.com"
$mail.subject = "Output of given task"
$mail.HTMLBody = "$te"
$mail.send() 
 

