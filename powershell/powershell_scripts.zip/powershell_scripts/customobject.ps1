﻿$a = get-| select -First 5 
$b = $a|select @{
                   name = 'name';
                  e={$_.processname}},@{
                                name = 'handles';
                                e={$_.handles}}

