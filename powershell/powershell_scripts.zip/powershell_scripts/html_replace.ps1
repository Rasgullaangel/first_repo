﻿$a=Get-WmiObject -class win32_logicaldisk | select @{n='capacity';e={$_.size/1gb}},@{n='FreeSpace';e={$_.FreeSpace/1gb}}
$b=Get-WmiObject -class Win32_PerfFormattedData_Tcpip_NetworkInterface |
    Select @{n='Nic_Card';e={$_.name}},CurrentBandWidth |?{$_.Nic_Card -like 'intel*'}
$c= Get-WmiObject -class win32_processor | select loadpercentage,@{n='CPU';e={$_.name}}
$output=@()
$d=@()
$d=get-content -path C:\Users\pulakanam.v\Desktop\vijay.txt
for($i=0;$i -lt 5;$i++) {
 
$a1=$O = New-Object PSObject;
$a2=$O | Add-Member NoteProperty "Servers" $d[$i];
$a3=$O | Add-Member NoteProperty "Cpu" $c.Cpu;
$a4=$O | Add-Member NoteProperty "LoadPercentage" $c.loadpercentage;
$a5=$O | Add-Member NoteProperty "NicCard" $b.Nic_Card;
$a6=$O | Add-Member NoteProperty "CurrentBandwidth" $b.CurrentBandWidth;
$a7=$O | Add-Member NoteProperty "Capacity" $a.capacity;
$a8=$O | Add-Member NoteProperty "FreeSPace" $a.FreeSpace;
$Output += $O;
 
} 
$text = $output | ConvertTo-Html
$text1 = $text -replace '<table>','<Table border=1 cellpadding=0 cellspacing=0>'
$ou = New-Object -ComObject outlook.application
$mail = $ou.CreateItem(0)
$mail.to = "pulakanam.v@hcl.com"
$mail.subject = "Output of given task"
$mail.HTMLBody=$true
$mail.HTMLBody = "$text1"
$mail.send() 



