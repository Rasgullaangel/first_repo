﻿#disk partition
$c=Get-WmiObject -Class win32_diskpartition | Select  name,primarypartition,size
$d = $c |select @{name = 'size';e={$_.size/1gb}},"name","primarypartition"| Format-Table -Force

#top5 utilising process
 $a=Get-WMIObject -class Win32_Process | Sort-Object vs -desc | Select -first 5 |Select-Object -Property virtualsize,ProcessName,Handles 
 $b = $a |select @{name = 'virtualsize';e={$_.virtualsize/1gb}},handles,processname

 #top 5 utilising services
 $a=Get-WMIObject -class Win32_service | Sort-Object -desc | Select-Object -first 5 |Select-Object -Property processid,state,name



