﻿New-Item -ItemType directory -Path C:\Users\pulakanam.v\Desktop\myinventory
Move-Item C:\Users\pulakanam.v\Desktop\powershell -Destination C:\Users\pulakanam.v\Desktop\myinventory
$a=Get-ChildItem -Path C:\Users\pulakanam.v\Desktop\myinventory -Recurse
$b=$a | Sort-Object -Property @{expression = "lastwritetime"; descending = $false}
$c = $b.lastwritetime.toshortdatestring()


$obj = @()
$i = 0
$j = 1
foreach($item in $b){
       
  if($c[$i] -eq $c[$j]){
       Write-Host "asd"
        Write-Host "sdf"
      $var=new-item -ItemType directory -path C:\Users\pulakanam.v\Desktop\myinventory\$c
      Move-Item $b[$i] -Destination $var


}
}

        

