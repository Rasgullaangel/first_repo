﻿#disk space details
$logical = Get-WmiObject -Class win32_logicaldisk|select pscomputername,name,size,filesystem 
$disk_part = Get-WmiObject -Class win32_diskpartition | Select  name,primarypartition,size

#top 5 memory utilising process
$process = Get-wmiobject WIN32_process|sort-object -Property virtualsize |Select-Object -Last 5 name,virtualsize,processid

#top 5 memory utilising services
$b= Get-WmiObject -class win32_process -namespace root/cimv2 | Sort virtualsize -Descending|select Processid,Name,@{n='Memory Consumed (GB)';e={$_.virtualsize/1gb}} -First 50
$count1=0
$z=gwmi -class win32_service | ?{$_.processid -ne '0'}
$count=$z.count
$y=$z | %{for($i=0;$i -lt $count;$i++)
                                {if($_.processid -eq $b.processid[$i])
                                     { $_.name}
                                     } } 
$ans=$y|select -first 5  

#currently using network interface name
$net = (Get-WmiObject Win32_Networkadapter)| select @{n='networkadapter';e={$_.servicename}}-First 5  

#top 5 largest files
$large = Get-wmiobject -Query "ASSOCIATORS OF {Win32_Directory.Name='C:\Users\pulakanam.v\desktop'} Where ResultClass = CIM_DataFile" |Select filesize,filename,extension|sort-object -Property filesize -Descending|select -First 5

#last created files in c
$create = Get-wmiobject -Query "ASSOCIATORS OF {Win32_Directory.Name='C:\Users\pulakanam.v\desktop'} Where ResultClass = CIM_DataFile" |Select @{name = 'creationdate';expression = {$_.converttodatetime($_.creationdate)}},filename,extension|sort-object -Property creationdate -Descending|select -First 5

#creating into an object
$final =@() 
$j = 0
for ($i = 0; $i -le 5; $i++)
{ 
    $final_out = new-object psobject
    $final_out|Add-Member NoteProperty "diskspace"        $logical.size[$i]
    $final_out|Add-Member NoteProperty "diskspace1"        $disk_part.size[$i]
    $final_out|Add-Member NoteProperty "top5process"      $process.name[$i]
    $final_out|Add-Member NoteProperty "top5processsize"      $process.virtualsize[$i]
    $final_out|Add-Member NoteProperty "top5service"      $ans[$i]
    $final_out|Add-Member NoteProperty "networkadapter" $net.networkadapter[$i]
    $final_out|Add-Member NoteProperty "largestfiles"     $large.filesize[$i]
    $final_out|Add-Member NoteProperty "name"     $large.filename[$i]
    $final_out|Add-Member NoteProperty "lastcreatedfiles" $create.creationdate[$i]
    $final += $final_out
    $j++

}  
$g = $final | Format-Table -AutoSize 

