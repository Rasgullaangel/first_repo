﻿#passthru command
Get-Command | ?{$_.Parameters.Keys -contains "passthru"` -and $_.CommandType -contains "cmdlet"}