﻿function get-ADD{
param(
[parameter(mandatory=$true)]
[int]$val1,
[parameter(mandatory=$true)]
[int]$val2,
[parameter(mandatory=$true)]
[string] $path
)

PROCESS{
$val1+$val2

}
}
