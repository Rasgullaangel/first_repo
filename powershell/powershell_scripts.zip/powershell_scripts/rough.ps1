﻿Get-CimClass  | ?{$_.CimClassName -like "*sound*"}
Get-WmiObject -Class win32_sounddevice 
Get-WmiObject -Class win32_sounddevice | gm *
#reset
#setpowerstate

#statusinfo
#installdate

#select reset from win32_sounddevice



$a = Get-NetIPAddress | select ipaddress
foreach($ping in $a){
        $b = ping[$ping]

    if($b[-3][-12] -eq '0'){
    $ping |select @{
                   name = 'ipaddress';
                  e={$_.ipaddress + " " + "pinging"}}}
    else{
    $ping |select @{
                   name = 'ipaddress';
                  e={$_.ipaddress + " " + "not pinging"}}}
                  }


$a = Get-NetIPAddress | select ipaddress
foreach($ping in $a){
    $b = ping[$ping]
    #$b[-3][-12]
    }