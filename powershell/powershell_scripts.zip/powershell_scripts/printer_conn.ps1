﻿Get-WmiObject -class win32_printer -ComputerName
(New-Object -ComObject wscript.network).enumprinterconnection()
(New-Object -ComObject wscript.network).addwindowsprinterconnection("\\printserver01\xerox5")
(Get-WmiObject -ComputerName . -Class win32_printer -Filter "name='HP LASERJET5SI'").setdefaultprinter()
(New-Object -ComObject wscript.network)setdefaultprinter('HP LASERJET5SI')
(New-Object -ComObject wscript.network).removeprinterconnection("\\printserver01\xerox5")