﻿$a= get-service | select -first 5
$b= get-process | select -First 5
$c=@()
$i=0
foreach($row in $a){
$d=New-Object -TypeName psobject 
Add-Member -InputObject $d -MemberType NoteProperty -Name 'handles' -Value $b.handles[$i];
Add-Member -InputObject $d -MemberType NoteProperty -Name 'NPM(k)'  -Value $b.NPM[$i];
Add-Member -InputObject $d -MemberType NoteProperty -Name 'PM(k)'  -Value $b.PM[$i];
Add-Member -InputObject $d -MemberType NoteProperty -Name 'status' -Value $row.status;
Add-Member -InputObject $d -MemberType NoteProperty -Name 'name' -Value $row.name;
Add-Member -InputObject $d -MemberType NoteProperty -Name 'displayname' -Value $row.displayname
$c = $c + $d
$i++
 } 
$c | format-table -AutoSize 
