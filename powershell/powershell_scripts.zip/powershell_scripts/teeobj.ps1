﻿#tee-object
#filepath
Get-Process | select -first 5| Tee-Object -FilePath C:\Users\pulakanam.v\Desktop\t1.csv
#variable
Get-Process | select-first 5 | select handles| Tee-Object -Variable pro
Get-Process | select-first 5 | Tee-Object -Variable pro | select handles
#append
get-service | select -First 5 | Tee-Object -Append | out-file -FilePath C:\Users\pulakanam.v\Desktop\t1.csv
