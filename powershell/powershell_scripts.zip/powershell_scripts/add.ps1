﻿function add{
param($number)
$number + 1

}