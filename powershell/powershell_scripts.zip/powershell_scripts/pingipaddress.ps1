﻿$a = Get-NetIPAddress | select ipaddress
$a.count
$b = @("128.0.0.0","123.11.1.11.11","192.168.43.215","192.168.43.215")
$b.count
for ($i = 1; $i -le $b.count; $i++)
{ if(ping($b[$i]) -eq $true){
    $ping |select @{
                   name = 'ipaddress';
                  e={$b[$i]}}}
    else{
    $ping |select @{
                   name = 'ipaddress';
                  e={$b[$i]}}}
    
}
<#foreach($ping[$i] in $b){
    
    if(ping($ping) -eq $false){
    $ping |select @{
                   name = 'ipaddress';
                  e={$b}}}
    else{
    $ping |select @{
                   name = 'ipaddress';
                  e={$b}}}
}#>