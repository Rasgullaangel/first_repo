﻿describe 'Add' {

    $TestNumber = 1
    $result = Add -Number $TestNumber

    it 'should return 2' {
        $result | should be 2
    }

}