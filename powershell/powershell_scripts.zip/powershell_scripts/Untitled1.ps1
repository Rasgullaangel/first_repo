﻿$d=@()
$output=@()
$d=get-content -path C:\Users\pulakanam.v\Desktop\vijay.txt
for($i=0;$i -lt 5;$i++) {
$O = New-Object PSObject;
$O | Add-Member NoteProperty "Servers" $d[$i];
$a=Get-WmiObject -class win32_logicaldisk -ComputerName $d[$i] | select @{n='capacity';e={((($_.size)-($_.freespace))/($_.size))*100}},@{n='FreeSpace';e={($_.FreeSpace/$_.size)*100}}
$O | Add-Member NoteProperty "Capacity" $a.capacity;
$O | Add-Member NoteProperty "FreeSPace" $a.FreeSpace;
$b=Get-WmiObject -class Win32_PerfFormattedData_Tcpip_NetworkInterface -ComputerName $d[$i] |
    Select @{n='Nic_Card';e={$_.name}},@{n='current';e={($_.currentbandwidth/100000000)*100}} |?{$_.Nic_Card -like 'intel*'}
$O | Add-Member NoteProperty "NicCard" $b.Nic_Card;
$O | Add-Member NoteProperty "Current" $b.Current;
$c= Get-WmiObject -class win32_processor -ComputerName $d[$i] | select loadpercentage,@{n='CPU';e={$_.name}} 
$O | Add-Member NoteProperty "Cpu" $c.Cpu;
$O | Add-Member NoteProperty "LoadPercent" $c.loadpercentage;


$Output += $O;
 
} 
$path="C:\Users\pulakanam.v\desktop\task.txt"
$text = $output | ConvertTo-Html
$text1 = $text -replace '<table>','<Table border=1 cellpadding=0 cellspacing=0>'
$ou = New-Object -ComObject outlook.application
$mail = $ou.CreateItem(0)
$mail.to = "senthilnathanp@hcl.com"
$mail.subject = "task output"
$mail.HTMLBody= "$text1"
$mail.attachments.add($path)
$mail.send() 
