﻿#set the alias
#existing alias can't be changed
#new alias can be created
set-alias -name gs -Value Get-Service