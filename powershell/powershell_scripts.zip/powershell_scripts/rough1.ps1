﻿$a = Get-WmiObject -Class win32_networkadapter | select name,servicename | Where-Object servicename -eq 'ndiswan'
$b = Get-WmiObject -class win32_perfformatteddata_tcpip_networkinterface | select currentbandwidth,name | Where-Object name -eq 'Teredo Tunneling Pseudo-Interface'
$c = Get-WmiObject -Class win32_logicaldisk | select name,size
$d = Get-WmiObject -class win32_process | Select-Object virtualsize,path | Where-Object path -EQ 'c:\windows\system32\svchost.exe'
$e = Get-WmiObject -class win32_process -namespace root/cimv2 | Sort virtualsize -Descending|select Processid,Name,@{n='Memory Consumed (GB)';e={$_.virtualsize/1gb}} -First 5
$f = Get-PSDrive | select name,used,provider | Where-Object name -EQ 'c'
$s = Get-Content -Path C:\Users\pulakanam.v\Desktop\vijay.txt
foreach($a in $s){
foreach($row in $a){
$d=New-Object -TypeName psobject 
Add-Member -InputObject $d -MemberType NoteProperty -Name 'handles' -Value $b.handles[$i];
} }
