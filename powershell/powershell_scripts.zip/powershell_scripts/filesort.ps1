﻿New-Item -ItemType directory -Path C:\Users\pulakanam.v\Desktop\myinventory
Move-Item C:\Users\pulakanam.v\Desktop\powershell -Destination C:\Users\pulakanam.v\Desktop\myinventory
$a=Get-ChildItem -Path C:\Users\pulakanam.v\Desktop\myinventory -Recurse
$b=$a | Sort-Object -Property @{expression = "lastwritetime"; descending = $false}
$b.lastwritetime
$obj = @()
$i = 0
$b.lastwritetime.month + "," + $b.lastwritetime.day