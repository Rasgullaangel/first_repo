﻿$file = write-host " enter the path"
$excel = New-Object -ComObject excel.application
$excel.visible = $true
$workbook = $excel.workbooks.open($file)
$workbookname = "test.xls"
$out_type = ".xls"

if($workbook.worksheets.count -gt 0){
                Write-Output "$workbookname"
                $fileformat = [microsoft.office.interop.excel.xlfileformat]::xlopenxmlworkbook
                $workbookname = $file -replace ".xlsx" , ""

foreach($worksheet in $workbook.worksheets){
                $newfile = $workbookname + "~~" + $worksheet.name + "." + $out_type
                $worksheet.saveas($newfile,$fileformat)
                Write-Output "created file:$newfile"
                }
                }
$workbook.close()
